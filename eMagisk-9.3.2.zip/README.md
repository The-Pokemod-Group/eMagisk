# eMagisk

Installs useful binaries: bash, nano, strace, eventrec and tcpdump. Also optionally installs ATV resources.

## Changelog

### 5.4
- Everything seems to be verkin.

### 4.0
- Suddenly, things work. `bash` runs automatically when opening an `adb shell` without the need to recompile `adbd`.
- Also, following new practices and unity versions.

### 3.6
- Can't even make a changelog.

### 2.1
- Bash completion
- Auto installs busybox utilities
- Better aliases

### v1.1
- Trying to make `bash` open by default when running `adb shell` without having to recompile `adbd`.

### v1.0
- Project forked by @esauvisky
- New PS1, PS2 and PS3.
- Different aliases.
- A custom built `bash` binary.
- Other binaries bundled in, like `eventrec` and `strace`.